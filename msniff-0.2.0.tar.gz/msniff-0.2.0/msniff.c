/* $Id: msniff.c,v 1.18 2007-02-22 18:39:54 sverrehu Exp $ */
/*------------------------------------------------------------------------
 |  FILE            msniff.c
 |
 |  DESCRIPTION     Extremely simple sniffer of MSN Messenger messages.
 |                  Does nothing to trace sessions, it just displays
 |                  every message.  Unfortunately, outgoing messages
 |                  do not contain a sender identification, so you'll
 |                  have to identify users on your network through their
 |                  computers' IP addresses.
 |
 |  WRITTEN BY      Sverre H. Huseby <shh@thathost.com>
 +----------------------------------------------------------------------*/

#define __USE_STRING_INLINES

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#include <netinet/ether.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>

#include <shhmsg.h>
#include <shhopt.h>

#include <pcap.h>

#define DEFAULT_PORT 1863

/*-----------------------------------------------------------------------+
|  PRIVATE DATA                                                          |
+-----------------------------------------------------------------------*/

enum {
    INBOUND,
    OUTBOUND
};

static pcap_t *ph;
static char *dev = "eth0";
static char *host = NULL;
static char *filename = NULL;
static char errbuf[PCAP_ERRBUF_SIZE];
static int *messenger_ports;
static int num_messenger_ports;

/*-----------------------------------------------------------------------+
|  PRIVATE FUNCTIONS                                                     |
+-----------------------------------------------------------------------*/

static void *
xmalloc(size_t bytes)
{
    void *ret;

    if ((ret = malloc(bytes)) == NULL)
        msgFatal("out of memory\n");
    return ret;
}

static void *
xrealloc(void *ptr, size_t bytes)
{
    if ((ptr = realloc(ptr, bytes)) == NULL)
        msgFatal("out of memory\n");
    return ptr;
}

static void
getTextualAddress(int addr, int port, char *s, int n)
{
    snprintf(s, n, "%u.%u.%u.%u:%u",
             (addr >> 24) & 0xff, (addr >> 16) & 0xff,
             (addr >> 8) & 0xff, addr & 0xff, port);
    s[n - 1] = '\0';
}

static void
strAppend(char **dst, const char *src)
{
    int dstlen, nbytes;

    if (src == NULL)
        return;
    if (*dst != NULL)
        dstlen = strlen(*dst);
    else
        dstlen = 0;
    nbytes = dstlen + strlen(src) + 1;
    if (*dst == NULL) {
        *dst = xmalloc(nbytes);
        **dst = '\0';
    } else
        *dst = xrealloc(*dst, nbytes);
    strcpy(*dst + dstlen, src);
}

static void
utf8C1Clean(char *s)
{
    int c, val;

    while (*s) {
        c = *s & 0xff;
        if ((c & 0xe0) != 0xc0) {
            ++s;
            continue;
        }
        val = (c & 0x1f) << 6;
        if (*(s + 1)) {
            c = *(s + 1) && 0x3f;
            val |= c;
            msgVerbose(2, "val: %d\n", val);
            if ((val >= 127 && val <= 160) || val > 255) {
                *s = ' ';
                ++s;
                *s = ' ';
            }
        }
        ++s;
    }
}

static void
makePrintable(char *s)
{
    int c;

    while (*s) {
        c = *s & 0xff;
        if (c < ' ' && c != '\r' && c != '\n') {
            *s = '.';
        }
        ++s;
    }
}

static char *
formatMessage(const char *s)
{
#define MAX_LINE_LEN 78
    const char *word_start, *word_end;
    char *p;
    char *ret = NULL;
    char *prefix = "  ";
    int prefix_len;
    int curr_line_len = 0;
    int add_len;
    int newline_found;

    prefix_len = strlen(prefix);
    while (*s) {
        newline_found = 0;
        while (*s && isspace(*s)) {
            if (*s == '\r' || *s == '\n')
                newline_found = 1;
            ++s;
        }
        if (!*s)
            break;
        word_start = s;
        while (*s && !isspace(*s))
            ++s;
        word_end = s;
        add_len = word_end - word_start;

        if (add_len < MAX_LINE_LEN - prefix_len
            && curr_line_len + add_len > MAX_LINE_LEN)
            newline_found = 1;
        if (newline_found && ret != NULL) {
            strAppend(&ret, "\n");
            strAppend(&ret, prefix);
            curr_line_len = prefix_len;
        }
        if (curr_line_len == 0) {
            strAppend(&ret, prefix);
            curr_line_len = prefix_len;
        }
        if (curr_line_len > prefix_len) {
            strAppend(&ret, " ");
            ++curr_line_len;
        }
        p = xmalloc(add_len + 1);
        strncpy(p, word_start, add_len);
        p[add_len] = '\0';
        strAppend(&ret, p);
        curr_line_len += add_len;
        free(p);
    }
    if (ret == NULL) {
        ret = xmalloc(1);
        msgFatal("out of memory\n");
        *ret = '\0';
    }
    return ret;
}

static const char *
getTimestamp(time_t sec)
{
    static char ret[32];
    struct tm *tm;

    tm = localtime(&sec);

    strftime(ret, sizeof(ret), "%Y-%m-%d %H:%M:%S", tm);
    ret[sizeof(ret) - 1] = '\0';  /* just in case */
    return ret;
}

static int
isMessengerPort(int port)
{
    int q;

    for (q = 0; q < num_messenger_ports; q++)
        if (messenger_ports[q] == port)
            return 1;
    return 0;
}

static void
handleInstantMessage(const char *src, const char *dst,
                     int direction, u_char *data, time_t sec)
{
    char *p;
    char *name_start, *name_end, *name;
    int name_len, name_allocated = 0;
    char *formatted;

    if (strstr((char *) data, "Content-Type: text/plain") == NULL) {
        msgVerbose(1, "unknown message\n");
        return;
    }

    if (direction == INBOUND) {
        p = (char *) data + 3;
        while (*p && isspace(*p))
            ++p;
        if (p == NULL)
            return;
        name_start = p;
        while (*p && !isspace(*p))
            ++p;
        name_end = p;
        name_len = name_end - name_start;
        name = xmalloc(name_len + 1);
        name_allocated = 1;
        strncpy(name, name_start, name_len);
        name[name_len] = '\0';
    } else
        name = "INSIDE USER";
    printf("%s %s (%s -> %s)\n", getTimestamp(sec), name, src, dst);
    if (name_allocated) {
        free(name);
    }
    if ((p = strstr((char *) data, "\r\n\r\n")) == NULL) {
        printf("  [couldn't find start of message body]\n");
        return;
    }
    utf8C1Clean(p);
    formatted = formatMessage(p);
    printf("%s\n\n", formatted);
    free(formatted);
}

static int
indexOf(const char *haystack, int offs, const char *needle)
{
    const char *p;

    p = strstr(haystack + offs, needle);
    if (p == NULL) {
        return -1;
    }
    return p - haystack;
}

static void
handleAllMessagesInPacket(const char *src, const char *dst,
                          int direction, u_char *data, int len, time_t sec)
{
    int offs = 0;
    char *start, *p, *p2;
    char *content;
    int message_length, nbytes;

    for (;;) {
        offs = indexOf((const char *) data, offs, "MSG ");
        if (offs < 0 || offs >= len - 4) {
            return;
        }
        if (offs == 0 || (offs >= 2 && data[offs - 2] == '\r'
                          && data[offs - 1] == '\n')) {
            start = p = (char *) &data[offs];
            while (*p != '\r' && *p != '\n' && p < (const char *) data + len) {
                ++p;
            }
            p2 = p;
            if (*p == '\r') {
                ++p;
            }
            if (*p == '\n') {
                ++p;
            }
            if (*p2 == '\r' || *p2 == '\n') {
                while (isdigit(*(p2 - 1))) {
                    --p2;
                }
                message_length = atoi(p2);
                nbytes = p - start + message_length;
                content = xmalloc(nbytes + 1);
                strncpy(content, start, nbytes);
                content[nbytes] = '\0';
                handleInstantMessage(src, dst, direction,
                                     (u_char *) content, sec);
                free(content);
            }
            offs = (p - (char *) data) + message_length;
        } else {
            offs += 1;
        }
    }
}

static void
packetHandler(u_char *user, const struct pcap_pkthdr *hdr, const u_char *data)
{
    const struct ether_header *ether_head;
    const struct iphdr *ip_head;
    const struct tcphdr *tcp_head;
    const u_char *payload;
    int len;
    int saddr, daddr;
    int sport, dport;
    char src[32], dst[32];
    char *mypayload;
    int direction;

    ether_head = (const struct ether_header *) data;
    if (ntohs(ether_head->ether_type) != ETHERTYPE_IP) {
        msgVerbose(1, "got non-IP packet (type %x)\n",
                   (int) ether_head->ether_type);
        return;
    }

    msgVerbose(3, "got IP packet\n");
    ip_head = (const struct iphdr *) (ether_head + 1);

    if (ip_head->protocol != IPPROTO_TCP) {
        msgVerbose(1, "got non-TCP packet (protocol %d)\n",
                   (int) ip_head->protocol);
        return;
    }

    msgVerbose(3, "got TCP packet\n");
    tcp_head = (const struct tcphdr *) ((const u_char *) ip_head
                                                   + ip_head->ihl * 4);
    payload = ((const u_char *) tcp_head + (tcp_head->doff * 4));
    len = ntohs(ip_head->tot_len) - (int) (payload - (const u_char *) ip_head);

    if (len == 0) {
        msgVerbose(3, "got package without payload\n");
        return;
    }
    if (len < 0 || len > 65535) {
        msgVerbose(1, "length is %d, and I didn't like that.\n", len);
        return;
    }

    mypayload = xmalloc(len + 1);
    memcpy(mypayload, payload, len);
    mypayload[len] = '\0';

    saddr = ntohl(ip_head->saddr);
    daddr = ntohl(ip_head->daddr);
    sport = ntohs(tcp_head->source);
    dport = ntohs(tcp_head->dest);
    getTextualAddress(saddr, sport, src, sizeof(src));
    getTextualAddress(daddr, dport, dst, sizeof(dst));
    if (isMessengerPort(sport))
        direction = INBOUND;
    else
        direction = OUTBOUND;

#if 0
    if (strncmp(mypayload, "MSG", 3) == 0) {
        handleInstantMessage(src, dst, direction, (u_char *) mypayload);
    } else {
        makePrintable(mypayload);
        msgVerbose(4, "  [%s]\n", mypayload);
    }
#else
    handleAllMessagesInPacket(src, dst, direction, (u_char *) mypayload, len,
                              hdr->ts.tv_sec);
#endif
    free(mypayload);
}

static char *
getPortExpression(int port)
{
    static char ret[64];

    snprintf(ret, sizeof(ret), "port %d", port);
    return ret;
}

static void
startSniffing(void)
{
    struct bpf_program filter;
    char *filter_expr = NULL;
    bpf_u_int32 dev_ip;
    bpf_u_int32 netmask;
    int q;

    if (filename != NULL) {
        if ((ph = pcap_open_offline(filename, errbuf)) == NULL)
            msgFatal("pcap_open_offline: %s\n", errbuf);
    } else {
        if ((ph = pcap_open_live(dev, 32768, 1, 0, errbuf)) == NULL)
            msgFatal("pcap_open_live: %s\n", errbuf);
        if (pcap_lookupnet(dev, &dev_ip, &netmask, errbuf) == -1)
            msgFatal("pcap_lookupnet: %s\n", errbuf);

        if (host != NULL) {
            strAppend(&filter_expr, "host ");
            strAppend(&filter_expr, host);
            strAppend(&filter_expr, " and ");
        }
        strAppend(&filter_expr, "(");
        for (q = 0; q < num_messenger_ports; q++) {
            if (q > 0)
                strAppend(&filter_expr, " or ");
            strAppend(&filter_expr, getPortExpression(messenger_ports[q]));
        }
        strAppend(&filter_expr, ")");

        if (pcap_compile(ph, &filter, filter_expr, 0, dev_ip) == -1)
            msgFatal("pcap_compile: %s\n", pcap_geterr(ph));
        if (pcap_setfilter(ph, &filter) == -1)
            msgFatal("pcap_setfilter: %s\n", pcap_geterr(ph));
    }

    if (filename != NULL) {
        fprintf(stderr, "reading from `%s'.  filter: %s\n",
                filename, filter_expr);
    } else {
        fprintf(stderr, "listening on interface %s.  filter: %s\n",
                dev, filter_expr);
    }

    if (pcap_loop(ph, -1, packetHandler, NULL) == -1)
        msgFatal("pcap_loop: %s\n", pcap_geterr(ph));
}

static void
usage(void)
{
    printf(
      "usage: %s [options] interface [host [port ...]]\n"
      "\n"
      "       host may be ANY (the default) to listen to all hosts\n"
      "\n"
      "  -h, --help                     display this help and exit\n"
      "  -v, --verbose                  increase verbosity level\n"
      "  -V, --version                  output version information and exit\n"
      "\n",
      msgGetName());
    exit(0);
}

static void
version(void)
{
    printf(
      "%s " VERSION ", by Sverre H. Huseby "
      "(compiled " COMPILED_DATE " by " COMPILED_BY ")\n",
      msgGetName()
    );
    exit(0);
}

static void
incVerbose(void)
{
    ++msgVerboseLevel;
}

/*-----------------------------------------------------------------------+
|  PUBLIC FUNCTIONS                                                      |
+-----------------------------------------------------------------------*/

int
main(int argc, char *argv[])
{
    int q, w;
    optStruct opt[] = {
      /* short long           type        var/func    special       */
        { 'h', "help",        OPT_FLAG,   usage,      OPT_CALLFUNC },
        { 'r', "read-file",   OPT_STRING, &filename,  0            },
        { 'v', "verbose",     OPT_FLAG,   incVerbose, OPT_CALLFUNC },
        { 'V', "version",     OPT_FLAG,   version,    OPT_CALLFUNC },
        { 0, 0, OPT_END, 0, 0 }  /* no more options */
    };

    msgSetName(argv[0]);
    optParseOptions(&argc, argv, opt, 0);
    if (argc < 2) {
        usage();
    }
    dev = argv[1];
    if (argc >= 3 && strcmp(argv[2], "ANY") != 0)
        host = argv[2];
    if (argc >= 4) {
        num_messenger_ports = argc - 4 + 1;
        messenger_ports = xmalloc(num_messenger_ports * sizeof(int));
        for (q = 3, w = 0; q < argc; q++, w++) {
            messenger_ports[w] = atoi(argv[q]);
        }
    } else {
        num_messenger_ports = 1;
        messenger_ports = xmalloc(num_messenger_ports * sizeof(int));
    }

    setvbuf(stdout, NULL, _IOLBF, 0);
    setvbuf(stderr, NULL, _IOLBF, 0);

    startSniffing();
    return 0;
}
